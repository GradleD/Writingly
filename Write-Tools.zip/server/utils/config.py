import os
from dotenv import load_dotenv

load_dotenv()

# keys
openai_api_key = os.getenv("OPENAI_API_KEY")    